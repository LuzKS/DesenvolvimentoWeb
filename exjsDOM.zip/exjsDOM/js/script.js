function aluno() {
    var boxant = document.getElementById("informacao-prof");
    boxant.style.display = "none";

    var box = document.getElementById("informacao-aluno");
    box.style.display = "block";

}

function professor() {
    var boxant = document.getElementById("informacao-aluno");
    boxant.style.display = "none";
    var box = document.getElementById("informacao-prof");
    box.style.display = "block";

}

function adicionarAluno(){
    var box = document.getElementById("informacao-aluno");
    
    var nome = prompt("digite o nome do aluno: ");

    var text = document.createTextNode(`Aluno: ${nome}`);

    var bxoInfo = document.createElement("P");

    box.appendChild(bxoInfo);
    bxoInfo.appendChild(text);
    box.insertBefore(bxoInfo, butaoA);
}

function adicionarProf(){
    var nome = prompt("digite o nome do professor: ");
}