aberto = false;
function clicou() {
    let dMenu = document.getElementById("dMenu");
    if (aberto == false) {
        dMenu.style.display = "block";
        aberto = true;

    }
    else {
        dMenu.style.display = "none";
        aberto = false;
    }

}

function limite(){
    // let usuario = getElementById("iUsuario").value
    var mensagem = getElementById("sUsuario");
    mensagem.style.display = "block";
    // if(usuario.length == 0){
    //     let p = document.createElement("p");
    //     divC.appendChild(p);
    //     p.appendChild(text);
    // }
}

